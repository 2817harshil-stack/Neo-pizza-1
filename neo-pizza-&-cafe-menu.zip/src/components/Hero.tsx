import { motion } from 'motion/react';
import { ChefHat, Info } from 'lucide-react';

interface HeroProps {
  selectedTable: number | null;
  onSelectTable: (tableNum: number) => void;
}

export default function Hero({ selectedTable, onSelectTable }: HeroProps) {
  const tables = [1, 2, 3, 4];

  return (
    <section id="hero" className="relative min-h-[80vh] flex items-center justify-center bg-[#070707] overflow-hidden py-16 px-4">
      
      {/* Background Image Container */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1574071318508-1cdbab80d002?q=80&w=1600&auto=format&fit=crop"
          alt="Handcrafted wood-fired Neapolitan Pizza Margherita"
          className="w-full h-full object-cover object-center opacity-40 scale-105"
          referrerPolicy="no-referrer"
        />
        {/* Gradients to fade background to rich charcoal black */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/70 to-[#0a0a0a]/30" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0a] via-[#0a0a0a]/40 to-[#0a0a0a]" />
      </div>

      {/* Hero Content */}
      <div className="relative z-10 max-w-4xl mx-auto text-center flex flex-col items-center">
        
        {/* Subtle Tagline Badge */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="flex items-center gap-2 px-4 py-1.5 rounded-full border border-[#c5a880]/30 bg-[#0a0a0a]/80 backdrop-blur-sm mb-6"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-[#859f7d]" />
          <span className="text-[11px] font-semibold tracking-[0.25em] text-[#c5a880] uppercase">
            Artisanal Pure Vegetarian
          </span>
        </motion.div>

        {/* Main Title Overlay */}
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="font-serif text-4xl sm:text-6xl md:text-7xl font-bold text-white tracking-tight leading-[1.1] mb-6 max-w-3xl"
        >
          Neo-Politan Style. <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#e5cfb3] via-[#c5a880] to-[#e5cfb3]">
            Pure Veg Perfection.
          </span>
        </motion.h1>

        {/* Elegant Description */}
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-gray-400 text-sm sm:text-base md:text-lg tracking-wide max-w-2xl font-light leading-relaxed mb-12"
        >
          We raise our 48-hour slow-fermented 00' dough to blister and bubble in our 450°C wood-fired oven. Pure ingredients. Exquisite flavor. No Maida. No Mayonnaise. Just pure Italian passion.
        </motion.p>

        {/* Table Number Selector (Ordered Interaction) */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="w-full max-w-xl bg-[#121212]/95 border border-[#c5a880]/20 rounded-2xl p-6 sm:p-8 backdrop-blur-md shadow-2xl"
        >
          <div className="flex items-center justify-center gap-2 mb-4">
            <ChefHat className="w-4 h-4 text-[#c5a880]" />
            <h3 className="font-serif text-lg sm:text-xl font-medium tracking-wider text-[#e5cfb3]">
              Select Your Table to Begin
            </h3>
          </div>
          
          <p className="text-xs text-gray-500 tracking-wide mb-6">
            Dine-in at Neo Pizza & Cafe? Select your table below to easily customize your digital cart and place your order directly.
          </p>

          {/* Table Grid */}
          <div className="grid grid-cols-4 gap-3 sm:gap-4">
            {tables.map((tableNum) => {
              const isSelected = selectedTable === tableNum;
              return (
                <button
                  key={tableNum}
                  onClick={() => onSelectTable(tableNum)}
                  className={`relative py-4 sm:py-5 rounded-xl flex flex-col items-center justify-center gap-1.5 transition-all duration-300 border-2 cursor-pointer ${
                    isSelected
                      ? 'bg-[#1a2f1d]/60 border-[#859f7d] text-white shadow-[0_0_15px_rgba(133,159,125,0.15)]'
                      : 'bg-[#181818] border-[#c5a880]/15 text-gray-400 hover:border-[#c5a880]/40 hover:bg-[#1f1a14] hover:text-white'
                  }`}
                >
                  <span className="text-[10px] tracking-widest uppercase font-light opacity-60">
                    Table
                  </span>
                  <span className="font-serif text-xl sm:text-2xl font-bold">
                    0{tableNum}
                  </span>
                  {isSelected && (
                    <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-[#859f7d] shadow-[0_0_8px_#859f7d]" />
                  )}
                </button>
              );
            })}
          </div>

          {selectedTable ? (
            <div className="mt-5 flex items-center justify-center gap-1.5 text-xs text-[#86efac] font-medium tracking-wide">
              <span className="w-1.5 h-1.5 rounded-full bg-[#859f7d] animate-ping" />
              <span>Ordering active for Table 0{selectedTable}</span>
            </div>
          ) : (
            <div className="mt-5 flex items-center justify-center gap-1.5 text-xs text-[#c5a880]/70 font-medium tracking-wide">
              <Info className="w-3.5 h-3.5" />
              <span>Please choose table 1, 2, 3, or 4 before checkout</span>
            </div>
          )}
        </motion.div>

      </div>

      {/* Decorative Marble/Stone Edge Gradient at Bottom */}
      <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-[#0a0a0a] to-transparent pointer-events-none" />
    </section>
  );
}
