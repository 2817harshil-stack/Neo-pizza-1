import React, { useState, useEffect } from 'react';
import { Order } from '../types';
import { ChefHat, CheckCircle2, AlertCircle, Clock, Trash2, ArrowLeft, ShieldAlert, Lock, Unlock, RefreshCw, QrCode } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import TableQRManager from './TableQRManager';

interface KitchenDashboardProps {
  onBackToStore: () => void;
}

export default function KitchenDashboard({ onBackToStore }: KitchenDashboardProps) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');
  
  const [orders, setOrders] = useState<Order[]>([]);
  const [activeTab, setActiveTab] = useState<'all' | 'Pending' | 'Preparing' | 'Completed'>('all');
  const [isQRView, setIsQRView] = useState(false);

  // Load orders and subscribe to storage changes for multi-tab synchronization
  useEffect(() => {
    const loadOrders = () => {
      const saved = localStorage.getItem('neo_orders');
      if (saved) {
        try {
          setOrders(JSON.parse(saved));
        } catch (e) {
          console.error('Failed to parse orders', e);
        }
      } else {
        setOrders([]);
      }
    };

    loadOrders();

    // Listen to changes from other tabs/clients
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'neo_orders') {
        loadOrders();
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  // Save orders to localStorage and dispatch custom event for current tab synchronization
  const saveOrders = (updatedOrders: Order[]) => {
    setOrders(updatedOrders);
    localStorage.setItem('neo_orders', JSON.stringify(updatedOrders));
    // Trigger storage event manually for same-tab updates if any other components are listening
    window.dispatchEvent(new Event('storage'));
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'neo123') {
      setIsAuthenticated(true);
      setPasswordError('');
    } else {
      setPasswordError('Invalid credentials. Hint: Default password is neo123');
    }
  };

  const handleUpdateStatus = (orderId: string, newStatus: Order['status']) => {
    const updated = orders.map((order) => 
      order.id === orderId ? { ...order, status: newStatus } : order
    );
    saveOrders(updated);
  };

  const handleDeleteOrder = (orderId: string) => {
    if (window.confirm('Are you sure you want to delete this order from history?')) {
      const updated = orders.filter((order) => order.id !== orderId);
      saveOrders(updated);
    }
  };

  const handleClearHistory = () => {
    if (window.confirm('Are you sure you want to clear completed & cancelled orders? This action is irreversible.')) {
      const updated = orders.filter((order) => order.status === 'Pending' || order.status === 'Preparing');
      saveOrders(updated);
    }
  };

  // Filtered orders
  const filteredOrders = orders.filter((order) => {
    if (activeTab === 'all') return true;
    return order.status === activeTab;
  }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  // Count stats
  const pendingCount = orders.filter((o) => o.status === 'Pending').length;
  const preparingCount = orders.filter((o) => o.status === 'Preparing').length;
  const completedCount = orders.filter((o) => o.status === 'Completed').length;

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#070707] flex flex-col justify-center items-center px-4 py-12">
        <div className="absolute top-6 left-6">
          <button
            onClick={onBackToStore}
            className="flex items-center gap-2 text-xs font-semibold tracking-widest text-[#c5a880] hover:text-white transition-colors uppercase"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Menu
          </button>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md bg-[#111111] rounded-2xl border border-[#c5a880]/15 p-8 shadow-2xl relative overflow-hidden"
        >
          {/* Decorative design details */}
          <div className="absolute top-0 inset-x-0 h-[3px] bg-gradient-to-r from-transparent via-[#c5a880]/40 to-transparent" />
          <div className="absolute -top-12 -right-12 w-32 h-32 rounded-full bg-[#c5a880]/5 blur-2xl pointer-events-none" />

          <div className="flex flex-col items-center text-center space-y-4 mb-8">
            <div className="w-14 h-14 rounded-full bg-[#c5a880]/10 border border-[#c5a880]/20 flex items-center justify-center text-[#c5a880]">
              <Lock className="w-6 h-6 animate-pulse" />
            </div>
            <div className="space-y-1">
              <h2 className="font-serif text-2xl font-bold text-white tracking-wide">Kitchen Entrance</h2>
              <p className="text-xs text-gray-400 font-light max-w-xs leading-relaxed">
                Authorized access only. Enter the owner password to access real-time order logs.
              </p>
            </div>
          </div>

          <form onSubmit={handleLogin} className="space-y-5">
            <div className="space-y-2">
              <label className="text-[10px] text-gray-500 uppercase tracking-widest font-bold block">
                Owner Password
              </label>
              <input
                type="password"
                required
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-[#161616] border border-gray-800 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-700 focus:outline-none focus:border-[#c5a880] transition-colors tracking-widest"
              />
            </div>

            {passwordError && (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-[#241311] border border-red-900/30 text-xs text-red-400 font-medium">
                <ShieldAlert className="w-4 h-4 shrink-0" />
                <span>{passwordError}</span>
              </div>
            )}

            <button
              type="submit"
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#e5cfb3] to-[#c5a880] text-black hover:from-white hover:to-[#e5cfb3] transition-all font-bold text-xs tracking-widest uppercase shadow-lg shadow-[#c5a880]/10 cursor-pointer"
            >
              Unlock Dashboard
            </button>
          </form>

          <div className="mt-8 pt-6 border-t border-gray-900 text-center">
            <p className="text-[11px] text-gray-500 font-light">
              Don't know the password? Use the default password <span className="font-mono text-[#c5a880] font-semibold">neo123</span>
            </p>
          </div>
        </motion.div>
      </div>
    );
  }

  if (isQRView) {
    return <TableQRManager onBack={() => setIsQRView(false)} />;
  }

  return (
    <div className="min-h-screen bg-[#070707] text-[#f5f5f5] flex flex-col">
      {/* Dashboard Top Header */}
      <header className="border-b border-[#c5a880]/10 bg-[#111111]/90 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-4">
          
          <div className="flex items-center gap-3">
            <button
              onClick={onBackToStore}
              className="p-2 rounded-lg bg-[#1a1a1a] hover:bg-[#222] border border-gray-800 text-gray-400 hover:text-white transition-all cursor-pointer"
              title="Return to Menu"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-2">
              <ChefHat className="w-5 h-5 text-[#c5a880]" />
              <div>
                <h1 className="font-serif text-lg font-bold text-white tracking-wide flex items-center gap-2">
                  NEO-POLITAN KITCHEN
                  <span className="text-[10px] bg-[#859f7d]/10 text-[#859f7d] border border-[#859f7d]/20 px-2 py-0.5 rounded-full font-sans tracking-widest uppercase">
                    Live Sync
                  </span>
                </h1>
                <p className="text-[10px] text-gray-500 uppercase tracking-widest font-medium">Owner Order Center</p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsQRView(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#c5a880]/25 bg-[#c5a880]/5 text-[#c5a880] hover:bg-[#c5a880]/15 hover:text-white transition-all text-xs font-semibold uppercase tracking-wider cursor-pointer"
            >
              <QrCode className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Table QRs</span>
            </button>
            <button
              onClick={handleClearHistory}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-red-900/20 bg-red-950/10 text-red-400 hover:bg-red-950/20 hover:text-red-300 transition-all text-xs font-semibold uppercase tracking-wider cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Clear Finished</span>
            </button>
            <button
              onClick={() => {
                // Manual refresh
                const saved = localStorage.getItem('neo_orders');
                if (saved) setOrders(JSON.parse(saved));
              }}
              className="p-2 rounded-lg bg-[#1a1a1a] border border-gray-800 text-gray-400 hover:text-white transition-all cursor-pointer"
              title="Force Refresh Sync"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>

        </div>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-8 space-y-8">
        
        {/* Real-time Order Stats Board */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-[#111] border border-[#c5a880]/10 p-4 rounded-xl flex items-center justify-between">
            <div>
              <p className="text-[10px] text-gray-500 uppercase tracking-widest font-semibold">Total Orders</p>
              <p className="font-serif text-2xl font-bold text-white mt-1">{orders.length}</p>
            </div>
            <div className="text-[#c5a880] bg-[#c5a880]/10 w-9 h-9 rounded-lg flex items-center justify-center text-sm font-bold">∑</div>
          </div>
          
          <div className="bg-[#111] border border-orange-500/10 p-4 rounded-xl flex items-center justify-between">
            <div>
              <p className="text-[10px] text-gray-500 uppercase tracking-widest font-semibold">Pending</p>
              <p className="font-serif text-2xl font-bold text-orange-400 mt-1">{pendingCount}</p>
            </div>
            <div className="text-orange-400 bg-orange-400/10 w-9 h-9 rounded-lg flex items-center justify-center">
              <Clock className="w-4 h-4 animate-pulse" />
            </div>
          </div>

          <div className="bg-[#111] border border-blue-500/10 p-4 rounded-xl flex items-center justify-between">
            <div>
              <p className="text-[10px] text-gray-500 uppercase tracking-widest font-semibold">Preparing</p>
              <p className="font-serif text-2xl font-bold text-blue-400 mt-1">{preparingCount}</p>
            </div>
            <div className="text-blue-400 bg-blue-400/10 w-9 h-9 rounded-lg flex items-center justify-center">
              <ChefHat className="w-4 h-4" />
            </div>
          </div>

          <div className="bg-[#111] border border-green-500/10 p-4 rounded-xl flex items-center justify-between">
            <div>
              <p className="text-[10px] text-gray-500 uppercase tracking-widest font-semibold">Completed</p>
              <p className="font-serif text-2xl font-bold text-green-400 mt-1">{completedCount}</p>
            </div>
            <div className="text-green-400 bg-green-400/10 w-9 h-9 rounded-lg flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
        </div>

        {/* Tab Filters */}
        <div className="flex border-b border-gray-900 pb-px">
          {(['all', 'Pending', 'Preparing', 'Completed'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-5 py-3 text-xs font-bold tracking-wider uppercase border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                activeTab === tab
                  ? 'border-[#c5a880] text-[#c5a880] bg-[#c5a880]/5'
                  : 'border-transparent text-gray-500 hover:text-white'
              }`}
            >
              {tab === 'all' ? 'All Orders' : tab}
              {tab === 'Pending' && pendingCount > 0 && (
                <span className="ml-1.5 px-1.5 py-0.5 bg-orange-500 text-black rounded-full text-[9px] font-bold">
                  {pendingCount}
                </span>
              )}
              {tab === 'Preparing' && preparingCount > 0 && (
                <span className="ml-1.5 px-1.5 py-0.5 bg-blue-500 text-black rounded-full text-[9px] font-bold">
                  {preparingCount}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Orders Listing Grid */}
        {filteredOrders.length === 0 ? (
          <div className="py-20 flex flex-col items-center justify-center text-center space-y-4 border border-dashed border-gray-800 rounded-2xl bg-[#0e0e0e]">
            <div className="w-12 h-12 rounded-full border border-[#c5a880]/15 flex items-center justify-center text-gray-500 text-lg">🗂️</div>
            <div className="space-y-1">
              <h3 className="text-sm font-semibold text-gray-300">No Orders Found</h3>
              <p className="text-xs text-gray-500 max-w-sm">
                There are no orders matching this tab filter currently in the system.
              </p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <AnimatePresence mode="popLayout">
              {filteredOrders.map((order) => (
                <motion.div
                  key={order.id}
                  layout
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.3 }}
                  className={`bg-[#111111] border rounded-2xl p-5 sm:p-6 flex flex-col justify-between space-y-5 shadow-xl relative overflow-hidden ${
                    order.status === 'Pending'
                      ? 'border-orange-500/20 shadow-orange-950/5'
                      : order.status === 'Preparing'
                      ? 'border-blue-500/20 shadow-blue-950/5'
                      : order.status === 'Completed'
                      ? 'border-green-500/10 opacity-75'
                      : 'border-gray-800'
                  }`}
                >
                  {/* Status strip */}
                  <div className={`absolute top-0 inset-x-0 h-[2.5px] ${
                    order.status === 'Pending'
                      ? 'bg-orange-500'
                      : order.status === 'Preparing'
                      ? 'bg-blue-500'
                      : order.status === 'Completed'
                      ? 'bg-green-500'
                      : 'bg-gray-700'
                  }`} />

                  {/* Order Card Header */}
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-serif text-lg font-extrabold text-[#e5cfb3]">
                          Table 0{order.tableNumber}
                        </span>
                        <span className="text-[10px] font-mono text-gray-500 tracking-wider">
                          #{order.id.slice(-5).toUpperCase()}
                        </span>
                      </div>
                      
                      <p className="text-sm text-white font-medium mt-1">
                        👤 {order.customerName || 'Anonymous'}
                      </p>
                      
                      <p className="text-[10px] text-gray-500 font-mono mt-1">
                        ⏰ {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>

                    <div className="flex flex-col items-end gap-2">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase border ${
                        order.status === 'Pending'
                          ? 'bg-[#221310] text-orange-400 border-orange-500/20'
                          : order.status === 'Preparing'
                          ? 'bg-[#0f1b29] text-blue-400 border-blue-500/20 animate-pulse'
                          : order.status === 'Completed'
                          ? 'bg-[#122214] text-green-400 border-green-500/20'
                          : 'bg-gray-900 text-gray-400 border-gray-800'
                      }`}>
                        {order.status}
                      </span>
                      <span className="font-serif text-sm font-semibold text-[#c5a880]">
                        ₹{order.totalPrice.toFixed(2)}
                      </span>
                    </div>
                  </div>

                  {/* Items List */}
                  <div className="bg-black/30 border border-gray-900/60 p-4 rounded-xl space-y-2.5">
                    {order.items.map((it, idx) => (
                      <div key={idx} className="flex justify-between text-xs font-light">
                        <div className="flex items-center gap-1.5">
                          <span className="text-gray-500 font-mono">[{it.quantity}x]</span>
                          <span className="text-gray-200 font-medium">{it.name}</span>
                        </div>
                        <span className="text-gray-400 font-mono">₹{(it.price * it.quantity).toFixed(0)}</span>
                      </div>
                    ))}
                  </div>

                  {/* Chef Actions at the bottom */}
                  <div className="flex flex-wrap items-center justify-between gap-3 border-t border-gray-900 pt-4 mt-auto">
                    <div className="flex items-center gap-2">
                      {order.status === 'Pending' && (
                        <button
                          onClick={() => handleUpdateStatus(order.id, 'Preparing')}
                          className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-black font-bold text-[10px] tracking-wider uppercase transition-all cursor-pointer"
                        >
                          🍳 Accept & Prepare
                        </button>
                      )}
                      {order.status === 'Preparing' && (
                        <button
                          onClick={() => handleUpdateStatus(order.id, 'Completed')}
                          className="px-4 py-2 rounded-lg bg-green-600 hover:bg-green-500 text-black font-bold text-[10px] tracking-wider uppercase transition-all cursor-pointer"
                        >
                          ✓ Ready to Serve
                        </button>
                      )}
                      {(order.status === 'Completed' || order.status === 'Cancelled') && (
                        <button
                          onClick={() => handleUpdateStatus(order.id, 'Pending')}
                          className="px-2.5 py-1.5 rounded-lg border border-gray-800 text-gray-400 hover:text-white text-[10px] font-bold tracking-wider uppercase transition-all cursor-pointer"
                        >
                          Re-open
                        </button>
                      )}
                      {order.status === 'Pending' && (
                        <button
                          onClick={() => handleUpdateStatus(order.id, 'Cancelled')}
                          className="px-2.5 py-1.5 rounded-lg border border-red-950 text-red-500 hover:bg-red-950/20 text-[10px] font-bold tracking-wider uppercase transition-all cursor-pointer"
                        >
                          Cancel
                        </button>
                      )}
                    </div>

                    <button
                      onClick={() => handleDeleteOrder(order.id)}
                      className="p-2 rounded-lg bg-[#161616] hover:bg-[#221310] border border-gray-800 hover:border-red-900/20 text-gray-500 hover:text-[#e07a5f] transition-all cursor-pointer"
                      title="Delete Order History Record"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}

      </main>
    </div>
  );
}
