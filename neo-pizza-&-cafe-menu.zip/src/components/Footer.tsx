import { Instagram, Phone, MapPin, Clock, ShieldCheck, Heart } from 'lucide-react';
import { APP_HIGHLIGHTS } from '../data';

interface FooterProps {
  onScrollToTop: () => void;
}

export default function Footer({ onScrollToTop }: FooterProps) {
  return (
    <footer id="app-footer" className="bg-[#070707] border-t border-[#c5a880]/15 relative overflow-hidden">
      
      {/* 1. HIGHLIGHT BAR (Unique Selling Points Section) */}
      <div className="border-b border-[#c5a880]/10 py-12 bg-gradient-to-b from-[#0a0a0a] to-[#070707]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {APP_HIGHLIGHTS.map((hl) => (
              <div 
                key={hl.id} 
                className="flex flex-col items-center lg:items-start text-center lg:text-left space-y-3 p-5 rounded-xl border border-gray-900/40 bg-[#121212]/30 hover:border-[#c5a880]/20 hover:bg-[#121212]/60 transition-all duration-300"
              >
                {/* Emoji Emblem */}
                <div className="w-12 h-12 rounded-full border border-[#c5a880]/15 bg-[#161616] flex items-center justify-center text-2xl shadow-inner">
                  {hl.emoji}
                </div>
                
                {/* Text Content */}
                <div className="space-y-1">
                  <h4 className="font-serif text-base font-bold text-white tracking-wide">
                    {hl.label}
                  </h4>
                  <p className="text-xs text-gray-500 leading-relaxed max-w-[240px] mx-auto lg:mx-0">
                    {hl.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 2. MAIN FOOTER CONTENT */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12 md:py-16 grid grid-cols-1 md:grid-cols-3 gap-10">
        
        {/* Brand Statement */}
        <div className="space-y-4 text-center md:text-left">
          <div className="flex flex-col items-center md:items-start justify-center">
            <span className="font-serif text-xl sm:text-2xl font-bold tracking-[0.2em] text-white leading-none whitespace-nowrap">
              NEO-POLITAN
            </span>
            <span className="font-serif text-xs font-light tracking-[0.15em] text-[#c5a880] uppercase mt-1.5 whitespace-nowrap">
              Pizza & Cafe
            </span>
          </div>
          <p className="text-xs text-gray-400 font-light leading-relaxed max-w-xs mx-auto md:mx-0">
            A premium, pure vegetarian establishment dedicating itself to the authentic, wood-fired culinary heritage of Naples. No compromise, only pure perfection.
          </p>
          <div className="flex items-center justify-center md:justify-start gap-1.5 text-[10px] text-gray-500 font-medium tracking-wide">
            <ShieldCheck className="w-4.5 h-4.5 text-[#859f7d]" />
            <span>FSSAI Certified Pure Veg Establishment</span>
          </div>
        </div>

        {/* Contact & Location Details */}
        <div className="space-y-4 text-center md:text-left">
          <h4 className="font-serif text-sm font-semibold text-[#c5a880] tracking-widest uppercase">
            Reservations & Orders
          </h4>
          
          <div className="space-y-2.5 flex flex-col items-center md:items-start text-xs text-gray-400">
            {/* Phone */}
            <a 
              href="tel:+918847753181" 
              className="flex items-center gap-2.5 hover:text-[#c5a880] transition-colors"
            >
              <Phone className="w-4 h-4 text-[#c5a880]" />
              <span>+91 88477 53181</span>
            </a>

            {/* Instagram */}
            <a 
              href="https://www.instagram.com/neopolitan_pizza.07" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="flex items-center gap-2.5 hover:text-[#c5a880] transition-colors"
            >
              <Instagram className="w-4 h-4 text-[#c5a880]" />
              <span>@neopolitan_pizza.07</span>
            </a>

            {/* Location (Indian region representation since +91 is the country code) */}
            <div className="flex items-center gap-2.5">
              <MapPin className="w-4 h-4 text-[#c5a880] shrink-0" />
              <span className="text-center md:text-left">Neo Pizza & Cafe, Premium Food Court, Landmark Circle, India</span>
            </div>
          </div>
        </div>

        {/* Operating Hours */}
        <div className="space-y-4 text-center md:text-left">
          <h4 className="font-serif text-sm font-semibold text-[#c5a880] tracking-widest uppercase">
            Operating Hours
          </h4>
          
          <div className="space-y-2.5 flex flex-col items-center md:items-start text-xs text-gray-400">
            <div className="flex items-center gap-2.5">
              <Clock className="w-4 h-4 text-[#c5a880]" />
              <span>Monday – Sunday: 12:00 PM – 11:30 PM</span>
            </div>
            
            <p className="text-[10px] text-gray-500 tracking-wide">
              *Kitchen closes 15 minutes before closing time.
            </p>
          </div>
        </div>

      </div>

      {/* 3. SUB FOOTER */}
      <div className="border-t border-[#c5a880]/10 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-[10px] text-gray-500 font-medium tracking-widest uppercase">
          
          <p>© {new Date().getFullYear()} NEO PIZZA & CAFE. ALL RIGHTS RESERVED.</p>
          
          <button 
            onClick={onScrollToTop}
            className="hover:text-white text-[#c5a880] transition-colors cursor-pointer"
          >
            BACK TO TOP ↑
          </button>

          <p className="flex items-center gap-1">
            CRAFTED WITH <Heart className="w-3 h-3 text-[#e07a5f] fill-current" /> FOR NEO-POLITAN LOVERS
          </p>

        </div>
      </div>

    </footer>
  );
}
