import { Instagram, Phone, ShoppingBag, Coffee, HelpCircle, ChefHat, Compass } from 'lucide-react';
import { motion } from 'motion/react';

interface HeaderProps {
  selectedTable: number | null;
  cartCount: number;
  onOpenCart: () => void;
  onTableClick: () => void;
  onOpenKitchen: () => void;
  onOpenTracker: () => void;
  hasActiveOrders: boolean;
}

export default function Header({ selectedTable, cartCount, onOpenCart, onTableClick, onOpenKitchen, onOpenTracker, hasActiveOrders }: HeaderProps) {
  return (
    <header id="app-header" className="sticky top-0 z-40 bg-[#0a0a0a]/90 backdrop-blur-md border-b border-[#c5a880]/15 py-4 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        
        {/* Brand & Crest */}
        <div className="flex items-center justify-between">
          <a href="#" className="flex items-center gap-3 group">
            {/* Minimal Pizza Silhouette / Crest */}
            <div className="relative w-10 h-10 rounded-full border border-[#c5a880]/40 flex items-center justify-center bg-[#121212] overflow-hidden group-hover:border-[#c5a880] transition-colors">
              <div className="absolute inset-0 bg-[#c5a880]/5 opacity-0 group-hover:opacity-100 transition-opacity" />
              <svg 
                viewBox="0 0 24 24" 
                fill="none" 
                className="w-6 h-6 text-[#c5a880] stroke-[1.5]" 
                stroke="currentColor"
              >
                <path d="M12 2L2 22h20L12 2z" strokeLinejoin="round" />
                <path d="M12 2v20M2.5 21l16-16M21.5 21L5.5 5" opacity="0.3" />
                <circle cx="9" cy="14" r="1" fill="currentColor" />
                <circle cx="15" cy="14" r="1" fill="currentColor" />
                <circle cx="12" cy="10" r="1.2" fill="currentColor" />
              </svg>
            </div>
            <div className="flex flex-col justify-center">
              <span className="font-serif text-base xs:text-lg sm:text-xl font-bold tracking-[0.12em] text-white leading-none whitespace-nowrap">
                NEO-POLITAN
              </span>
              <span className="font-serif text-[9px] sm:text-xs font-light tracking-[0.15em] text-[#c5a880] uppercase leading-none mt-1 whitespace-nowrap">
                Pizza & Cafe
              </span>
            </div>
          </a>

          {/* Mobile Cart & Table Actions */}
          <div className="flex items-center gap-1.5 xs:gap-2 md:hidden">
            {/* Live Order Tracker Mobile Trigger */}
            <button
              onClick={onOpenTracker}
              className={`relative p-1.5 rounded-full border transition-all ${
                hasActiveOrders
                  ? 'border-[#859f7d] bg-[#121212] text-[#859f7d] hover:text-white'
                  : 'border-[#c5a880]/20 bg-[#121212] text-[#c5a880]'
              }`}
              title="Track your live order status"
            >
              <Compass className={`w-4.5 h-4.5 ${hasActiveOrders ? 'animate-pulse' : ''}`} />
              {hasActiveOrders && (
                <span className="absolute top-0 right-0 w-2 h-2 rounded-full bg-[#859f7d] border border-[#0a0a0a]" />
              )}
            </button>

            {/* Table Badge */}
            <button
              onClick={onTableClick}
              className={`flex items-center gap-1 px-2 py-1 rounded-full text-[9px] font-bold tracking-wider uppercase border transition-all duration-300 ${
                selectedTable
                  ? 'bg-[#1a2f1d] border-[#3a6d44] text-[#86efac]'
                  : 'bg-[#1a1510] border-[#c5a880]/30 text-[#c5a880]'
              }`}
            >
              {selectedTable ? `T-0${selectedTable}` : 'Table'}
            </button>

            {/* Cart Button */}
            <button
              onClick={onOpenCart}
              className="relative p-1.5 rounded-full border border-[#c5a880]/20 bg-[#121212] hover:border-[#c5a880] transition-all"
              aria-label="Open cart"
            >
              <ShoppingBag className="w-4.5 h-4.5 text-[#c5a880]" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#859f7d] text-black text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center animate-bounce">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Contact info, Social & Table Select (Desktop) */}
        <div className="hidden md:flex items-center gap-6">
          {/* Phone */}
          <a 
            href="tel:+918847753181" 
            className="flex items-center gap-2 text-xs sm:text-sm font-medium tracking-wider text-gray-300 hover:text-[#c5a880] transition-colors shrink-0"
          >
            <Phone className="w-4 h-4 text-[#c5a880] shrink-0" />
            <span className="whitespace-nowrap">+91 88477 53181</span>
          </a>

          {/* Instagram */}
          <a 
            href="https://www.instagram.com/neopolitan_pizza.07" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center gap-2 text-xs sm:text-sm font-medium tracking-wider text-gray-300 hover:text-[#c5a880] transition-colors"
            title="Follow Neo-Politan Pizza on Instagram"
          >
            <Instagram className="w-4 h-4 text-[#c5a880]" />
            <span className="sr-only sm:not-sr-only">@neopolitan_pizza.07</span>
          </a>

          {/* Divider */}
          <span className="h-4 w-[1px] bg-[#c5a880]/20" />

          {/* Kitchen Login button */}
          <button
            onClick={onOpenKitchen}
            className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-[#c5a880] font-semibold tracking-wider transition-colors cursor-pointer"
            title="Owner Kitchen Dashboard"
          >
            <ChefHat className="w-3.5 h-3.5 text-[#c5a880]" />
            <span>KITCHEN</span>
          </button>

          {/* Table Selector badge */}
          <button
            onClick={onTableClick}
            className={`flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-semibold tracking-widest uppercase border transition-all duration-300 ${
              selectedTable
                ? 'bg-[#1a2f1d] border-[#3a6d44] text-[#86efac]'
                : 'bg-[#1a1510] border-[#c5a880]/30 text-[#c5a880] hover:border-[#c5a880] hover:bg-[#1f1912]'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-current animate-pulse" />
            {selectedTable ? `Table ${selectedTable} Active` : 'Select Table Number'}
          </button>

          {/* Live Order Tracker Trigger (Desktop) */}
          <button
            onClick={onOpenTracker}
            className={`relative flex items-center gap-2 px-4 py-1.5 rounded-full border bg-[#121212] transition-all cursor-pointer ${
              hasActiveOrders
                ? 'border-[#859f7d]/60 text-[#859f7d] hover:bg-[#1a221b] hover:border-[#859f7d]'
                : 'border-[#c5a880]/30 text-[#c5a880] hover:bg-[#1a1510] hover:border-[#c5a880]'
            }`}
          >
            <Compass className={`w-4 h-4 ${hasActiveOrders ? 'animate-spin' : ''}`} style={{ animationDuration: '8s' }} />
            <span className="text-xs font-semibold tracking-wider">TRACK STATUS</span>
            {hasActiveOrders && (
              <span className="absolute -top-1 -right-1 bg-[#859f7d] text-black text-[8px] font-bold px-1.5 py-0.5 rounded-full">
                LIVE
              </span>
            )}
          </button>

          {/* Cart Icon (Desktop) */}
          <button
            onClick={onOpenCart}
            className="relative flex items-center gap-2 px-4 py-1.5 rounded-full border border-[#c5a880]/30 bg-[#121212] hover:bg-[#1a1510] hover:border-[#c5a880] text-[#c5a880] transition-all cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4" />
            <span className="text-xs font-semibold tracking-wider">CART</span>
            {cartCount > 0 ? (
              <span className="bg-[#859f7d] text-black text-[10px] font-bold px-2 py-0.5 rounded-full">
                {cartCount}
              </span>
            ) : (
              <span className="text-[10px] opacity-40">0</span>
            )}
          </button>
        </div>

        {/* Mobile Contact info & Social bottom row */}
        <div className="flex md:hidden items-center justify-between border-t border-[#c5a880]/10 pt-3 mt-1">
          <a 
            href="tel:+918847753181" 
            className="flex items-center gap-1.5 text-[11px] font-medium tracking-wider text-gray-400 shrink-0"
          >
            <Phone className="w-3.5 h-3.5 text-[#c5a880] shrink-0" />
            <span className="whitespace-nowrap">+91 88477 53181</span>
          </a>

          <button
            onClick={onOpenKitchen}
            className="flex items-center gap-1 text-[11px] font-medium tracking-wider text-gray-400 hover:text-[#c5a880] cursor-pointer"
          >
            <ChefHat className="w-3.5 h-3.5 text-[#c5a880]" />
            <span>Kitchen Portal</span>
          </button>

          <a 
            href="https://www.instagram.com/neopolitan_pizza.07" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 text-[11px] font-medium tracking-wider text-gray-400 hover:text-[#c5a880]"
          >
            <Instagram className="w-3.5 h-3.5 text-[#c5a880]" />
            <span>@neopolitan_pizza.07</span>
          </a>
        </div>

      </div>
    </header>
  );
}

