import { MenuItem } from '../types';
import { Sparkles, ShoppingBag, Check } from 'lucide-react';
import { motion } from 'motion/react';

interface MenuItemCardProps {
  key?: string;
  item: MenuItem;
  onAddToCart: (item: MenuItem) => void;
  cartCount: number;
}

export default function MenuItemCard({ item, onAddToCart, cartCount }: MenuItemCardProps) {
  // Pesto Delight - Special Feature Box
  if (item.isFeature) {
    return (
      <motion.div
        id={`menu-item-${item.id}`}
        initial={{ opacity: 0, y: 15 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-50px' }}
        transition={{ duration: 0.6 }}
        className="col-span-1 md:col-span-2 relative overflow-hidden rounded-2xl border-2 border-[#c5a880] bg-gradient-to-br from-[#13110d] via-[#0a0a09] to-[#171410] p-6 sm:p-8 shadow-[0_10px_40px_rgba(197,168,128,0.12)] group"
      >
        {/* Subtle decorative gold light flare */}
        <div className="absolute -top-12 -right-12 w-40 h-40 rounded-full bg-[#c5a880]/10 blur-2xl group-hover:bg-[#c5a880]/15 transition-all" />
        
        {/* Elegant internal double-border frame for artisanal feel */}
        <div className="absolute inset-2.5 rounded-xl border border-[#c5a880]/15 pointer-events-none" />
        <div className="absolute inset-3 rounded-lg border border-[#c5a880]/5 pointer-events-none" />

        {/* Featured Ribbon / Badge */}
        <div className="absolute top-5 right-5 flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-gradient-to-r from-[#e5cfb3] to-[#c5a880] text-black text-[10px] font-bold uppercase tracking-widest shadow-md z-10">
          <Sparkles className="w-3 h-3 animate-spin" style={{ animationDuration: '6s' }} />
          <span>Chef's Masterpiece</span>
        </div>

        <div className="flex flex-col md:flex-row gap-6 lg:gap-8 justify-between relative z-10 h-full">
          {item.image && (
            <div className="w-full md:w-52 lg:w-60 h-48 md:h-52 lg:h-60 rounded-xl overflow-hidden border border-[#c5a880]/30 shadow-2xl relative shrink-0 self-center">
              <img
                src={item.image}
                alt={item.name}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent pointer-events-none" />
            </div>
          )}

          <div className="flex-1 space-y-4">
            
            {/* Title */}
            <div className="space-y-1">
              <span className="text-xs uppercase tracking-[0.25em] text-[#c5a880] font-semibold flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#859f7d]" />
                Premium Signature Selection
              </span>
              <h3 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-bold text-white tracking-wide leading-tight group-hover:text-[#e5cfb3] transition-colors">
                {item.name}
              </h3>
            </div>

            {/* Price Display */}
            <div className="flex items-center gap-3">
              <span className="font-sans text-3xl font-bold tracking-tight text-[#c5a880]">
                ₹{item.price}
              </span>
              <span className="px-2.5 py-1 rounded bg-[#1a2f1d] text-[#86efac] text-[10px] font-bold uppercase tracking-wider border border-[#3a6d44]/30 flex items-center gap-1">
                <span className="w-1 h-1 rounded-full bg-[#86efac] animate-pulse" />
                Updated Price
              </span>
            </div>

            {/* Description */}
            <p className="text-gray-300 text-sm sm:text-base font-light leading-relaxed max-w-xl">
              {item.description}
            </p>

            {/* USP Bullet Points inside feature box */}
            <div className="grid grid-cols-2 gap-x-4 gap-y-2.5 pt-2 text-[11px] sm:text-xs text-gray-400 font-medium tracking-wide border-t border-[#c5a880]/10 max-w-md">
              <div className="flex items-center gap-1.5">
                <span className="text-[#859f7d]">🌱</span> Pure Vegetarian
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-[#c5a880]">🌾</span> Tipo 00 Sourdough Crust
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-[#c5a880]">🚫</span> No Mayonnaise Added
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-[#859f7d]">✨</span> Housemade Basil Pesto
              </div>
            </div>
          </div>

          {/* Action Button */}
          <div className="flex md:flex-col items-center justify-between md:justify-center md:items-end gap-4 border-t border-[#c5a880]/10 md:border-t-0 pt-4 md:pt-0 shrink-0">
            <div className="text-left md:text-right hidden sm:block">
              <p className="text-[10px] text-gray-500 uppercase tracking-widest">Baking Status</p>
              <p className="text-xs text-white font-medium flex items-center gap-1 justify-end">
                <span className="w-1.5 h-1.5 rounded-full bg-[#859f7d] animate-ping" />
                Baked Fresh
              </p>
            </div>
            
            <button
              onClick={() => onAddToCart(item)}
              className="w-full md:w-auto relative flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-gradient-to-r from-[#e5cfb3] to-[#c5a880] text-black hover:from-white hover:to-[#e5cfb3] transition-all duration-300 font-semibold text-xs tracking-widest uppercase shadow-lg shadow-[#c5a880]/10 hover:shadow-[#c5a880]/20 active:scale-95 group cursor-pointer"
            >
              <ShoppingBag className="w-4 h-4 group-hover:-translate-y-0.5 transition-transform" />
              <span>ADD TO BASKET</span>
              {cartCount > 0 && (
                <span className="ml-1 bg-black text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Custom background texture simulation */}
        <div className="absolute inset-0 bg-[radial-gradient(#1c1c1c_1px,transparent_1px)] [background-size:16px_16px] opacity-10 pointer-events-none" />
      </motion.div>
    );
  }

  // Standard elegant menu card item with dot leaders and image
  return (
    <motion.div
      id={`menu-item-${item.id}`}
      initial={{ opacity: 0, y: 15 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-30px' }}
      transition={{ duration: 0.5 }}
      className="group relative flex flex-row items-start gap-4 sm:gap-5 p-4 sm:p-5 -mx-2 sm:-mx-3 rounded-2xl border-b border-[#c5a880]/10 hover:border-[#c5a880]/20 bg-[#0e0c0a]/0 hover:bg-[#13110d]/50 transition-all duration-300"
    >
      {item.image && (
        <div className="shrink-0 relative w-20 h-20 sm:w-24 sm:h-24 rounded-xl overflow-hidden border border-[#c5a880]/15 bg-[#121212] self-start mt-1">
          <img
            src={item.image}
            alt={item.name}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            referrerPolicy="no-referrer"
          />
        </div>
      )}

      <div className="flex-1 space-y-2 min-w-0">
        {/* Header row with name, dot leaders, and price */}
        <div className="flex items-start justify-between w-full gap-3">
          <div className="flex flex-col gap-1.5 min-w-0 flex-1">
            <h4 className="font-serif text-base sm:text-lg lg:text-xl font-bold text-white group-hover:text-[#c5a880] transition-colors break-words">
              {item.name}
            </h4>
            
            {/* Pop & Spicy Badges */}
            {(item.isPopular || (item.spicyLevel && item.spicyLevel > 0)) && (
              <div className="flex flex-wrap gap-1.5 items-center">
                {item.isPopular && (
                  <span className="shrink-0 px-2 py-0.5 rounded bg-[#1e1e1e] text-[#c5a880] text-[9px] font-bold uppercase tracking-wider border border-[#c5a880]/15">
                    Popular
                  </span>
                )}
                {item.spicyLevel && item.spicyLevel > 0 && (
                  <span className="shrink-0 text-[10px] tracking-widest text-[#e07a5f] font-medium leading-none">
                    {'🌶️'.repeat(item.spicyLevel)}
                  </span>
                )}
              </div>
            )}
          </div>

          {/* Dotted Leader Line */}
          <div className="hidden sm:block flex-1 border-b border-dotted border-[#c5a880]/20 mx-3 self-center" />

          {/* Price - Elegant bordered gold capsule */}
          <div className="shrink-0 px-3 py-1 rounded-full border border-[#c5a880]/30 bg-[#16120e] text-center shadow-[0_2px_8px_rgba(197,168,128,0.08)] group-hover:border-[#c5a880]/60 group-hover:bg-[#1f1913] transition-all duration-300 self-start">
            <span className="font-sans text-xs sm:text-sm font-semibold text-[#e5cfb3] group-hover:text-white tracking-wider whitespace-nowrap">
              ₹{item.price}
            </span>
          </div>
        </div>

        {/* Description & Action Button Row */}
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 sm:gap-4">
          <p className="text-gray-400 text-xs sm:text-sm font-light leading-relaxed sm:max-w-xl">
            {item.description}
          </p>

          <button
            onClick={() => onAddToCart(item)}
            className={`self-end sm:self-start shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-[10px] font-bold tracking-wider uppercase transition-all duration-300 cursor-pointer ${
              cartCount > 0
                ? 'bg-[#1a2f1d] border-[#3a6d44] text-[#86efac] hover:bg-[#233f27] shadow-[0_0_10px_rgba(134,239,172,0.05)]'
                : 'bg-[#121212] border-[#c5a880]/20 text-gray-400 hover:border-[#c5a880] hover:text-white hover:bg-[#1f1912]'
            }`}
          >
            {cartCount > 0 ? (
              <>
                <Check className="w-3.5 h-3.5 text-[#86efac]" />
                <span>ADDED ({cartCount})</span>
              </>
            ) : (
              <>
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>ADD</span>
              </>
            )}
          </button>
        </div>
      </div>
    </motion.div>
  );
}
