import { MenuItem } from '../types';
import MenuItemCard from './MenuItemCard';
import { ChefHat, Flame, Coffee } from 'lucide-react';

interface MenuSectionProps {
  items: MenuItem[];
  cartCountById: Record<string, number>;
  onAddToCart: (item: MenuItem) => void;
}

export default function MenuSection({ items, cartCountById, onAddToCart }: MenuSectionProps) {
  // Group items by category
  const pizzas = items.filter((item) => item.category === 'pizza');
  const maggi = items.filter((item) => item.category === 'maggi');
  const sidesAndBeverages = items.filter((item) => item.category === 'sides' || item.category === 'beverages');

  const categories = [
    { id: 'pizzas', name: 'Neo-Politan Pizzas', icon: ChefHat, count: pizzas.length },
    { id: 'maggi', name: 'Gourmet Maggi', icon: Flame, count: maggi.length },
    { id: 'sides-beverages', name: 'Sides & Beverages', icon: Coffee, count: sidesAndBeverages.length },
  ];

  const handleScroll = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      const headerOffset = 90; // offset for sticky header
      const elementPosition = el.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.scrollY - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth',
      });
    }
  };

  return (
    <section id="menu-section" className="py-12 px-4 sm:px-6 max-w-7xl mx-auto space-y-16">
      
      {/* Category Navigation Bar - Sticky Sub-header */}
      <div className="sticky top-[73px] sm:top-[77px] z-30 bg-[#0a0a0a]/95 backdrop-blur-md py-4 border-b border-[#c5a880]/10 flex overflow-x-auto gap-2 no-scrollbar scroll-smooth -mx-4 px-4 sm:mx-0 sm:px-0">
        <div className="flex gap-2 sm:gap-3 mx-auto">
          {categories.map((cat) => {
            const Icon = cat.icon;
            return (
              <button
                key={cat.id}
                onClick={() => handleScroll(cat.id)}
                className="flex items-center gap-2 px-4 py-2 rounded-full border border-[#c5a880]/15 bg-[#121212]/50 hover:bg-[#1a1510] hover:border-[#c5a880]/40 text-[#c5a880] hover:text-white transition-all text-xs font-semibold tracking-wider uppercase whitespace-nowrap cursor-pointer"
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{cat.name}</span>
                <span className="text-[10px] bg-[#c5a880]/10 px-1.5 py-0.5 rounded-full text-[#c5a880]">
                  {cat.count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 1. NEO-POLITAN PIZZAS */}
      <div id="pizzas" className="space-y-8 scroll-mt-24">
        {/* Section Heading */}
        <div className="text-center space-y-2">
          <span className="text-xs uppercase tracking-[0.3em] text-[#c5a880] font-semibold">Authentic 00' Flour</span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-wide">
            Neo-Politan Style Pizzas
          </h2>
          <div className="flex items-center justify-center gap-3 mt-4">
            <span className="w-12 h-[1px] bg-gradient-to-r from-transparent to-[#c5a880]/40" />
            <span className="text-xs text-[#c5a880] tracking-widest font-serif opacity-80">♦</span>
            <span className="w-12 h-[1px] bg-gradient-to-l from-transparent to-[#c5a880]/40" />
          </div>
        </div>

        {/* Feature Box at the top of Pizzas */}
        {pizzas.some(p => p.isFeature) && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {pizzas.filter(p => p.isFeature).map((item) => (
              <MenuItemCard
                key={item.id}
                item={item}
                onAddToCart={onAddToCart}
                cartCount={cartCountById[item.id] || 0}
              />
            ))}
          </div>
        )}

        {/* Non-Featured Pizzas - Elegant Grid or list */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-2">
          {pizzas.filter(p => !p.isFeature).map((item) => (
            <MenuItemCard
              key={item.id}
              item={item}
              onAddToCart={onAddToCart}
              cartCount={cartCountById[item.id] || 0}
            />
          ))}
        </div>
      </div>

      {/* 2. GOURMET MAGGI */}
      <div id="maggi" className="space-y-8 scroll-mt-24">
        {/* Section Heading */}
        <div className="text-center space-y-2">
          <span className="text-xs uppercase tracking-[0.3em] text-[#c5a880] font-semibold">Comfort Food Elevated</span>
          <h2 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-bold text-white tracking-wide">
            Maggi
          </h2>
          <div className="flex items-center justify-center gap-3 mt-4">
            <span className="w-12 h-[1px] bg-gradient-to-r from-transparent to-[#c5a880]/40" />
            <span className="text-xs text-[#c5a880] tracking-widest font-serif opacity-80">♦</span>
            <span className="w-12 h-[1px] bg-gradient-to-l from-transparent to-[#c5a880]/40" />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-2">
          {maggi.map((item) => (
            <MenuItemCard
              key={item.id}
              item={item}
              onAddToCart={onAddToCart}
              cartCount={cartCountById[item.id] || 0}
            />
          ))}
        </div>
      </div>

      {/* 3. SIDES & BEVERAGES */}
      <div id="sides-beverages" className="space-y-8 scroll-mt-24">
        {/* Section Heading */}
        <div className="text-center space-y-2">
          <span className="text-xs uppercase tracking-[0.3em] text-[#c5a880] font-semibold">Chilled & Crisp Pairings</span>
          <h2 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-bold text-white tracking-wide">
            Sides & Beverages
          </h2>
          <div className="flex items-center justify-center gap-3 mt-4">
            <span className="w-12 h-[1px] bg-gradient-to-r from-transparent to-[#c5a880]/40" />
            <span className="text-xs text-[#c5a880] tracking-widest font-serif opacity-80">♦</span>
            <span className="w-12 h-[1px] bg-gradient-to-l from-transparent to-[#c5a880]/40" />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-2">
          {sidesAndBeverages.map((item) => (
            <MenuItemCard
              key={item.id}
              item={item}
              onAddToCart={onAddToCart}
              cartCount={cartCountById[item.id] || 0}
            />
          ))}
        </div>
      </div>

    </section>
  );
}
