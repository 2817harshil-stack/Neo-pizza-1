import { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { ArrowLeft, Printer, Download, QrCode, Check, RefreshCw, Copy, ExternalLink } from 'lucide-react';
import { motion } from 'motion/react';

interface TableQRManagerProps {
  onBack: () => void;
}

export default function TableQRManager({ onBack }: TableQRManagerProps) {
  const tables = [1, 2, 3, 4];
  const [qrUrls, setQrUrls] = useState<Record<number, string>>({});
  const [copiedTable, setCopiedTable] = useState<number | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const getTableUrl = (tableNum: number) => {
    return `${window.location.origin}${window.location.pathname}?table=${tableNum}`;
  };

  const generateQRs = async () => {
    setIsGenerating(true);
    const urls: Record<number, string> = {};
    for (const table of tables) {
      const qrValue = getTableUrl(table);
      try {
        const url = await QRCode.toDataURL(qrValue, {
          width: 400,
          margin: 1,
          color: {
            dark: '#000000',
            light: '#ffffff'
          },
          errorCorrectionLevel: 'H'
        });
        urls[table] = url;
      } catch (err) {
        console.error('QR code generation error:', err);
      }
    }
    setQrUrls(urls);
    setIsGenerating(false);
  };

  useEffect(() => {
    generateQRs();
  }, []);

  const handleCopyLink = (tableNum: number) => {
    const url = getTableUrl(tableNum);
    navigator.clipboard.writeText(url).then(() => {
      setCopiedTable(tableNum);
      setTimeout(() => setCopiedTable(null), 2000);
    });
  };

  const handlePrintAll = () => {
    window.print();
  };

  const handlePrintSingle = (tableNum: number) => {
    // We can print a single card by hiding others using temporary style overrides or custom print triggers
    // A elegant way to do this is to assign a specific class to the print target
    const style = document.createElement('style');
    style.id = 'temp-print-style';
    style.innerHTML = `
      @media print {
        #print-section .table-card-print {
          display: none !important;
        }
        #print-section #table-card-print-${tableNum} {
          display: flex !important;
          margin: 0 auto !important;
          page-break-after: avoid !important;
        }
      }
    `;
    document.head.appendChild(style);
    window.print();
    // Clean up style after print window closes
    setTimeout(() => {
      const el = document.getElementById('temp-print-style');
      if (el) el.remove();
    }, 500);
  };

  const handleDownload = (tableNum: number) => {
    const dataUrl = qrUrls[tableNum];
    if (!dataUrl) return;
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = `neopolitan-table-0${tableNum}-qr.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-[#070707] text-[#f5f5f5] flex flex-col">
      
      {/* Dynamic CSS styles for professional printing */}
      <style dangerouslySetInnerHTML={{ __html: `
        @media print {
          /* Hide standard layouts */
          body * {
            visibility: hidden;
            background: white !important;
          }
          
          /* Show only the print container */
          #print-section, #print-section * {
            visibility: visible;
          }
          
          #print-section {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            height: auto;
            background: white !important;
            color: black !important;
            display: block !important;
            padding: 0 !important;
            margin: 0 !important;
          }

          .table-card-print {
            display: flex !important;
            page-break-inside: avoid !important;
            page-break-after: always !important;
            margin: 2rem auto !important;
            box-shadow: none !important;
            border: 3px solid #c5a880 !important;
            background: white !important;
            color: black !important;
          }

          .table-card-print:last-child {
            page-break-after: avoid !important;
          }
        }
      `}} />

      {/* Screen Header */}
      <header className="border-b border-[#c5a880]/10 bg-[#111111]/90 backdrop-blur-md sticky top-0 z-40 print:hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-2 rounded-lg bg-[#1a1a1a] hover:bg-[#222] border border-gray-800 text-gray-400 hover:text-white transition-all cursor-pointer"
              title="Back to Kitchen"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-2">
              <QrCode className="w-5 h-5 text-[#c5a880]" />
              <div>
                <h1 className="font-serif text-lg font-bold text-white tracking-wide">
                  Table QR Code Hub
                </h1>
                <p className="text-[10px] text-gray-500 uppercase tracking-widest font-medium">Digital Table Planner</p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={generateQRs}
              disabled={isGenerating}
              className="p-2 rounded-lg bg-[#1a1a1a] border border-gray-800 text-gray-400 hover:text-white transition-all cursor-pointer disabled:opacity-50"
              title="Regenerate QR Codes"
            >
              <RefreshCw className={`w-4 h-4 ${isGenerating ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={handlePrintAll}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-gradient-to-r from-[#e5cfb3] to-[#c5a880] text-black hover:from-white hover:to-[#e5cfb3] transition-all text-xs font-bold uppercase tracking-wider shadow-lg shadow-[#c5a880]/10 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Print All Cards</span>
            </button>
          </div>
        </div>
      </header>

      {/* Screen Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-8 space-y-8 print:hidden">
        
        {/* Intro Banner */}
        <div className="bg-[#111111] border border-[#c5a880]/10 rounded-2xl p-6 relative overflow-hidden">
          <div className="absolute top-0 inset-x-0 h-[3px] bg-gradient-to-r from-transparent via-[#c5a880]/40 to-transparent" />
          <div className="max-w-2xl space-y-2">
            <h2 className="font-serif text-xl font-bold text-white tracking-wide">How Table QR Codes Work</h2>
            <p className="text-xs text-gray-400 font-light leading-relaxed">
              Print these table cards and place them on your restaurant tables. When a guest scans the QR code with their mobile phone, the Neo-Politan digital menu will launch with the <span className="text-[#c5a880] font-semibold">Table Number automatically pre-selected</span> in their cart! No login or setup required.
            </p>
          </div>
        </div>

        {/* On-Screen Grid of Cards & Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {tables.map((tableNum) => {
            const qrUrl = qrUrls[tableNum];
            return (
              <motion.div
                key={tableNum}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: tableNum * 0.05 }}
                className="bg-[#111111] border border-gray-800 hover:border-[#c5a880]/30 rounded-2xl p-5 flex flex-col items-center justify-between gap-5 shadow-xl transition-all group"
              >
                
                {/* On-screen Preview of the Card */}
                <div className="w-full bg-white text-black p-4 rounded-xl border border-gray-200 flex flex-col items-center text-center space-y-4 shadow-md select-none">
                  {/* Card Brand Header */}
                  <div className="space-y-0.5">
                    <h3 className="font-serif text-sm font-black tracking-[0.12em] text-[#0f0e0c] leading-none">NEO-POLITAN</h3>
                    <p className="font-serif text-[8px] font-bold tracking-[0.18em] text-[#c5a880] uppercase leading-none">PIZZA & CAFE</p>
                  </div>
                  
                  {/* Table Selector Box */}
                  <div className="w-full border-t border-b border-[#c5a880]/20 py-1.5">
                    <span className="font-sans text-[7px] tracking-[0.2em] uppercase text-gray-400 font-bold leading-none block">WELCOME TO</span>
                    <h4 className="font-serif text-base font-extrabold text-[#0f0e0c] leading-none mt-0.5">TABLE 0{tableNum}</h4>
                  </div>

                  {/* QR Image Placeholder / Loader */}
                  <div className="p-1.5 bg-white border border-[#c5a880]/15 rounded-lg shadow-inner">
                    {qrUrl ? (
                      <img src={qrUrl} alt={`Table ${tableNum} QR Code`} className="w-24 h-24 object-contain" />
                    ) : (
                      <div className="w-24 h-24 bg-gray-100 animate-pulse rounded flex items-center justify-center text-[10px] text-gray-400">
                        Generating...
                      </div>
                    )}
                  </div>

                  {/* Tiny instruction Footer */}
                  <div className="space-y-0.5">
                    <p className="font-sans text-[7px] font-bold tracking-widest text-[#0f0e0c] uppercase leading-none">SCAN TO VIEW MENU</p>
                    <p className="text-[8px] text-gray-500 font-light leading-tight max-w-[140px] mx-auto">
                      Scan to view our fresh pure-veg menu & place order.
                    </p>
                  </div>
                </div>

                {/* Operations Panel */}
                <div className="w-full space-y-3">
                  <div className="text-center">
                    <span className="text-[10px] text-gray-500 uppercase tracking-widest font-mono">
                      Table 0{tableNum} QR Assets
                    </span>
                    <p className="text-[10px] text-gray-400 font-light truncate mt-1 select-all" title={getTableUrl(tableNum)}>
                      {getTableUrl(tableNum)}
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => handleCopyLink(tableNum)}
                      className="flex items-center justify-center gap-1 px-2 py-1.5 rounded-lg border border-gray-800 bg-[#151515] hover:bg-[#1a1a1a] hover:text-[#c5a880] text-gray-400 text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer"
                    >
                      {copiedTable === tableNum ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-green-500" />
                          <span>Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy Link</span>
                        </>
                      )}
                    </button>

                    <button
                      onClick={() => handleDownload(tableNum)}
                      disabled={!qrUrl}
                      className="flex items-center justify-center gap-1 px-2 py-1.5 rounded-lg border border-gray-800 bg-[#151515] hover:bg-[#1a1a1a] hover:text-[#c5a880] text-gray-400 text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer disabled:opacity-50"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download</span>
                    </button>
                  </div>

                  <button
                    onClick={() => handlePrintSingle(tableNum)}
                    disabled={!qrUrl}
                    className="w-full flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-[#c5a880]/10 hover:bg-[#c5a880]/20 border border-[#c5a880]/20 text-[#c5a880] hover:text-white text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer disabled:opacity-50"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Print Table 0{tableNum} Card</span>
                  </button>
                </div>

              </motion.div>
            );
          })}
        </div>
      </main>

      {/* Hidden container specifically for clean printer layouts */}
      <div id="print-section" className="hidden">
        {tables.map((tableNum) => {
          const qrUrl = qrUrls[tableNum];
          return (
            <div
              key={tableNum}
              id={`table-card-print-${tableNum}`}
              className="table-card-print flex flex-col items-center text-center p-12 bg-white text-black border-[4px] border-[#c5a880] rounded-3xl max-w-sm mx-auto shadow-none"
              style={{ width: '380px', height: '540px', boxSizing: 'border-box' }}
            >
              {/* Card Brand Header */}
              <div className="space-y-1 mb-4">
                <h2 className="font-serif text-3xl font-black tracking-[0.16em] text-[#0f0e0c] leading-none">NEO-POLITAN</h2>
                <p className="font-serif text-xs font-bold tracking-[0.22em] text-[#c5a880] uppercase leading-none mt-1">PIZZA & CAFE</p>
              </div>
              
              {/* Table Selector Box */}
              <div className="w-full border-t border-b border-[#c5a880]/30 py-4 my-4">
                <span className="font-sans text-[10px] tracking-[0.25em] uppercase text-gray-400 font-bold leading-none block">WELCOME TO</span>
                <h3 className="font-serif text-4xl font-extrabold text-[#0f0e0c] leading-none mt-2">TABLE 0{tableNum}</h3>
              </div>

              {/* QR Image */}
              <div className="p-3 bg-white border border-[#c5a880]/15 rounded-xl shadow-inner my-3">
                {qrUrl ? (
                  <img src={qrUrl} alt={`Table ${tableNum} QR Code`} className="w-48 h-48" />
                ) : (
                  <div className="w-48 h-48 bg-gray-100 rounded flex items-center justify-center text-xs text-gray-400">
                    Generating...
                  </div>
                )}
              </div>

              {/* instruction Footer */}
              <div className="space-y-2 mt-4">
                <p className="font-sans text-xs font-bold tracking-[0.15em] text-[#0f0e0c] uppercase leading-none">SCAN TO VIEW MENU</p>
                <p className="text-[11px] text-gray-500 font-light leading-relaxed max-w-[280px] mx-auto">
                  Scan this QR code with your phone camera to view our 100% pure veg menu & order directly from your table.
                </p>
              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
}
