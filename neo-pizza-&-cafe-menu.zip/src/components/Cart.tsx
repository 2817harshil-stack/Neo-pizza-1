import { useState, useEffect } from 'react';
import { CartItem, Order } from '../types';
import { X, Plus, Minus, Trash2, Send, ShoppingBag, AlertTriangle, User, ChefHat } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface CartProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  selectedTable: number | null;
  onSelectTable: (tableNum: number) => void;
  onUpdateQuantity: (itemId: string, delta: number) => void;
  onRemoveItem: (itemId: string) => void;
  onClearCart: () => void;
  onOrderPlaced?: (orderId: string) => void;
}

export default function Cart({
  isOpen,
  onClose,
  cart,
  selectedTable,
  onSelectTable,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onOrderPlaced
}: CartProps) {
  const [customerName, setCustomerName] = useState(() => {
    return localStorage.getItem('neo_customer_name') || '';
  });

  useEffect(() => {
    localStorage.setItem('neo_customer_name', customerName);
  }, [customerName]);

  const itemsCount = cart.reduce((acc, curr) => acc + curr.quantity, 0);
  const subtotal = cart.reduce((acc, curr) => acc + curr.menuItem.price * curr.quantity, 0);
  const total = subtotal; // GST Free

  const handlePlaceOrder = () => {
    if (!selectedTable) {
      alert("Please select a Table Number before placing your order.");
      return;
    }
    if (!customerName.trim()) {
      alert("Please enter your name. It will appear on your bill and order details.");
      return;
    }
    if (cart.length === 0) {
      alert("Your cart is empty. Add delicious items before checkout.");
      return;
    }

    // 1. Create a local order for the Kitchen Dashboard
    const newOrder: Order = {
      id: `order_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      tableNumber: selectedTable,
      customerName: customerName.trim(),
      items: cart.map((item) => ({
        menuItemId: item.menuItem.id,
        name: item.menuItem.name,
        quantity: item.quantity,
        price: item.menuItem.price,
      })),
      totalPrice: total,
      status: 'Pending',
      createdAt: new Date().toISOString(),
    };

    const savedOrdersStr = localStorage.getItem('neo_orders');
    let existingOrders: Order[] = [];
    if (savedOrdersStr) {
      try {
        existingOrders = JSON.parse(savedOrdersStr);
      } catch (e) {
        console.error('Failed to parse existing orders', e);
      }
    }
    existingOrders.push(newOrder);
    localStorage.setItem('neo_orders', JSON.stringify(existingOrders));

    // Save newly placed order ID to track it in real-time
    try {
      const savedIdsStr = localStorage.getItem('neo_placed_order_ids');
      const savedIds: string[] = savedIdsStr ? JSON.parse(savedIdsStr) : [];
      savedIds.push(newOrder.id);
      localStorage.setItem('neo_placed_order_ids', JSON.stringify(savedIds));
    } catch (e) {
      console.error('Failed to save tracked order ID', e);
    }

    window.dispatchEvent(new Event('storage')); // Trigger real-time sync in other components

    alert(`🎉 Order Placed Successfully!\n\nThank you, ${customerName.trim()}! Your order has been directly sent to our kitchen dashboard for Table 0${selectedTable}. We will start preparing your fresh dishes right away! 🍕🌱`);

    // Clear cart and close
    onClearCart();
    onClose();

    // Notify parent to open the tracker immediately
    if (onOrderPlaced) {
      onOrderPlaced(newOrder.id);
    }
  };


  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm"
          />

          {/* Cart Sidebar */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed right-0 top-0 bottom-0 z-50 w-full sm:max-w-md bg-[#0a0a0a] border-l border-[#c5a880]/20 flex flex-col justify-between shadow-2xl overflow-hidden"
          >
            {/* Header */}
            <div className="p-5 border-b border-[#c5a880]/15 flex items-center justify-between bg-[#121212]">
              <div className="flex items-center gap-2.5">
                <ShoppingBag className="w-5 h-5 text-[#c5a880]" />
                <div>
                  <h3 className="font-serif text-lg font-bold tracking-wide text-white">
                    Your Selection
                  </h3>
                  <p className="text-[10px] text-gray-500 uppercase tracking-widest font-medium">
                    {itemsCount} {itemsCount === 1 ? 'item' : 'items'} in basket
                  </p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-2 rounded-full border border-gray-800 text-gray-400 hover:text-white hover:border-[#c5a880]/40 transition-colors"
                aria-label="Close cart"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Cart Body */}
            <div className="flex-1 overflow-y-auto p-5 space-y-6">
              
              {/* Customer Name block inside cart */}
              <div className="p-4 rounded-xl bg-[#121212] border border-[#c5a880]/10 space-y-3">
                <p className="text-xs font-semibold text-[#e5cfb3] tracking-wide uppercase flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-[#c5a880]" />
                  Your Name (Required)
                </p>
                
                <input
                  type="text"
                  placeholder="Enter your name..."
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full bg-[#181818] border border-gray-800 rounded-lg px-3 py-2 text-xs text-white placeholder-gray-600 focus:outline-none focus:border-[#c5a880]/50 transition-colors"
                />

                <p className="text-[10px] text-gray-500 font-light leading-snug">
                  * This name will appear on the bill and order details.
                </p>
              </div>

              {/* Table Selector block inside cart */}
              <div className="p-4 rounded-xl bg-[#121212] border border-[#c5a880]/10 space-y-3">
                <p className="text-xs font-semibold text-[#e5cfb3] tracking-wide uppercase flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#859f7d]" />
                  Dine-In Table Number
                </p>
                
                <div className="grid grid-cols-4 gap-2">
                  {[1, 2, 3, 4].map((tableNum) => (
                    <button
                      key={tableNum}
                      onClick={() => onSelectTable(tableNum)}
                      className={`py-2 rounded-lg text-xs font-bold transition-all border cursor-pointer ${
                        selectedTable === tableNum
                          ? 'bg-[#1a2f1d] border-[#3a6d44] text-[#86efac]'
                          : 'bg-[#181818] border-gray-800 text-gray-400 hover:border-[#c5a880]/20 hover:text-white'
                      }`}
                    >
                      T-0{tableNum}
                    </button>
                  ))}
                </div>

                {!selectedTable && (
                  <div className="flex items-center gap-1.5 text-[11px] text-[#e07a5f] bg-[#221310] border border-[#e07a5f]/20 p-2 rounded-md">
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                    <span>Please choose your table number to complete order.</span>
                  </div>
                )}
              </div>

              {/* Items List */}
              {cart.length === 0 ? (
                <div className="h-60 flex flex-col items-center justify-center text-center space-y-4">
                  <div className="w-12 h-12 rounded-full border border-dashed border-[#c5a880]/40 flex items-center justify-center text-gray-500">
                    🍕
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-medium text-gray-300">Your basket is empty</p>
                    <p className="text-xs text-gray-500 max-w-[240px]">Browse our authentic wood-fired pizzas and gourmet delights to start adding.</p>
                  </div>
                  <button
                    onClick={onClose}
                    className="px-4 py-2 rounded-lg border border-[#c5a880]/30 text-xs text-[#c5a880] hover:bg-[#c5a880]/5 font-semibold tracking-wider uppercase cursor-pointer"
                  >
                    Explore Menu
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  <p className="text-[10px] text-gray-500 uppercase tracking-widest font-semibold border-b border-gray-800 pb-2">
                    Review Ordered Items
                  </p>

                  <div className="space-y-3 divide-y divide-gray-900">
                    {cart.map((item) => (
                      <div key={item.menuItem.id} className="pt-3 first:pt-0 flex items-start justify-between gap-4 group">
                        <div className="flex-1 space-y-1">
                          <h4 className="font-serif text-sm font-semibold text-white group-hover:text-[#c5a880] transition-colors">
                            {item.menuItem.name}
                          </h4>
                          <p className="text-xs text-[#c5a880] font-medium font-mono">
                            ₹{item.menuItem.price} each
                          </p>
                        </div>

                        {/* Quantity controls */}
                        <div className="flex items-center gap-2">
                          <div className="flex items-center bg-[#121212] border border-gray-800 rounded-lg overflow-hidden">
                            <button
                              onClick={() => onUpdateQuantity(item.menuItem.id, -1)}
                              className="p-1.5 text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="px-2.5 text-xs font-bold text-white font-mono">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => onUpdateQuantity(item.menuItem.id, 1)}
                              className="p-1.5 text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>

                          <button
                            onClick={() => onRemoveItem(item.menuItem.id)}
                            className="p-1.5 rounded-lg text-gray-500 hover:text-[#e07a5f] hover:bg-gray-900 transition-colors"
                            title="Remove item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="pt-2 text-right">
                    <button
                      onClick={onClearCart}
                      className="text-[10px] text-gray-500 hover:text-[#e07a5f] uppercase tracking-wider font-semibold cursor-pointer"
                    >
                      Clear All Items
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Cart Footer (Receipt & Checkout) */}
            {cart.length > 0 && (
              <div className="p-5 border-t border-[#c5a880]/15 bg-[#121212] space-y-5">
                
                {/* Invoice style receipt */}
                <div className="space-y-2 border border-dashed border-[#c5a880]/20 p-4 rounded-xl font-mono text-xs text-gray-400 bg-black/40">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span className="text-white">₹{subtotal.toFixed(2)}</span>
                  </div>
                  
                  {/* Dashed line */}
                  <div className="border-t border-dashed border-[#c5a880]/25 my-2" />
                  
                  <div className="flex justify-between text-sm font-bold">
                    <span className="text-[#e5cfb3]">Grand Total</span>
                    <span className="text-[#c5a880]">₹{total.toFixed(2)}</span>
                  </div>
                </div>

                {/* Submit button */}
                <button
                  onClick={handlePlaceOrder}
                  disabled={!selectedTable || !customerName.trim()}
                  className={`w-full py-4 px-6 rounded-xl font-bold text-xs tracking-widest uppercase flex items-center justify-center gap-2.5 shadow-lg transition-all duration-300 cursor-pointer ${
                    selectedTable && customerName.trim()
                      ? 'bg-[#859f7d] text-black hover:bg-[#a1ba99] shadow-black/30'
                      : 'bg-gray-800 text-gray-500 border border-gray-700 cursor-not-allowed'
                  }`}
                >
                  <ChefHat className="w-4 h-4 shrink-0" />
                  <span>Place Order to Kitchen</span>
                </button>

                {(!selectedTable || !customerName.trim()) && (
                  <p className="text-[10px] text-center text-[#e07a5f] font-semibold tracking-wider uppercase">
                    {!selectedTable && !customerName.trim()
                      ? 'Select table & enter name to unlock'
                      : !selectedTable
                      ? 'Select table number above to unlock'
                      : 'Enter your name above to unlock'}
                  </p>
                )}
              </div>
            )}

          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
