import { useState, useEffect } from 'react';
import { Order } from '../types';
import { 
  X, 
  Clock, 
  ChefHat, 
  CheckCircle2, 
  XCircle, 
  RefreshCw, 
  Flame, 
  Table, 
  Receipt, 
  Calendar,
  AlertTriangle,
  Compass
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface OrderTrackerProps {
  isOpen: boolean;
  onClose: () => void;
  selectedTable: number | null;
}

export default function OrderTracker({ isOpen, onClose, selectedTable }: OrderTrackerProps) {
  const [trackedOrders, setTrackedOrders] = useState<Order[]>([]);
  const [placedOrderIds, setPlacedOrderIds] = useState<string[]>([]);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());

  // Keep current time updated for live arrival counter
  useEffect(() => {
    if (!isOpen) return;
    const interval = setInterval(() => {
      setCurrentTime(new Date());
    }, 10000); // update every 10 seconds
    return () => clearInterval(interval);
  }, [isOpen]);

  // Load user's placed order IDs and synchronise order details
  const syncTrackedOrders = () => {
    try {
      const savedIdsStr = localStorage.getItem('neo_placed_order_ids');
      const savedOrdersStr = localStorage.getItem('neo_orders');
      
      let ids: string[] = [];
      let allOrders: Order[] = [];
      
      if (savedIdsStr) {
        ids = JSON.parse(savedIdsStr);
        setPlacedOrderIds(ids);
      }
      
      if (savedOrdersStr) {
        allOrders = JSON.parse(savedOrdersStr);
      }

      // Filter orders placed in this session or matches current customer/table as a fallback
      let userOrders = allOrders.filter(order => ids.includes(order.id));

      // Fallback: If no explicit session tracking, show active orders of the selected table
      if (userOrders.length === 0 && selectedTable !== null) {
        userOrders = allOrders.filter(
          order => order.tableNumber === selectedTable && 
          (order.status === 'Pending' || order.status === 'Preparing')
        );
      }

      // Sort by creation time (newest first)
      userOrders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setTrackedOrders(userOrders);
    } catch (e) {
      console.error('Error syncing tracked orders:', e);
    }
  };

  useEffect(() => {
    if (isOpen) {
      syncTrackedOrders();
    }

    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'neo_orders' || e.key === 'neo_placed_order_ids') {
        syncTrackedOrders();
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [isOpen, selectedTable]);

  const handleManualRefresh = () => {
    setIsRefreshing(true);
    syncTrackedOrders();
    setTimeout(() => {
      setIsRefreshing(false);
    }, 600);
  };

  // Helper to calculate estimated time remaining or status label
  const getETA = (order: Order) => {
    if (order.status === 'Completed') return 'Served!';
    if (order.status === 'Cancelled') return 'Cancelled';

    const createdTime = new Date(order.createdAt).getTime();
    const nowTime = currentTime.getTime();
    const elapsedMins = Math.floor((nowTime - createdTime) / 60000);
    
    // Average preparation is 15-20 minutes
    const totalEstMins = 20; 
    const remainingMins = totalEstMins - elapsedMins;

    if (remainingMins <= 0) {
      return 'Arriving any moment';
    }
    return `~${remainingMins} mins`;
  };

  // Status-specific styles & step progress index
  const getStatusProgress = (status: Order['status']) => {
    switch (status) {
      case 'Pending': return 1;
      case 'Preparing': return 2;
      case 'Completed': return 3;
      default: return 0; // Cancelled
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md"
            id="tracker-backdrop"
          />

          {/* Slide-over tracking panel */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 26, stiffness: 190 }}
            className="fixed right-0 top-0 bottom-0 z-50 w-full sm:max-w-md bg-[#0a0a0a] border-l border-[#c5a880]/20 flex flex-col justify-between shadow-2xl overflow-hidden"
            id="tracker-panel"
          >
            {/* Header */}
            <div className="p-5 border-b border-[#c5a880]/15 flex items-center justify-between bg-[#111]">
              <div className="flex items-center gap-2.5">
                <Compass className="w-5 h-5 text-[#c5a880]" />
                <div>
                  <h3 className="font-serif text-lg font-bold tracking-wide text-white">
                    Live Order Tracker
                  </h3>
                  <p className="text-[10px] text-[#c5a880]/70 uppercase tracking-widest font-medium">
                    Real-time Kitchen Status
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {/* Manual sync */}
                <button
                  onClick={handleManualRefresh}
                  disabled={isRefreshing}
                  className="p-2 rounded-full border border-gray-800 text-gray-400 hover:text-white hover:border-[#c5a880]/40 transition-colors disabled:opacity-50"
                  title="Refresh order status"
                  id="tracker-refresh-btn"
                >
                  <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-[#c5a880]' : ''}`} />
                </button>
                <button
                  onClick={onClose}
                  className="p-2 rounded-full border border-gray-800 text-gray-400 hover:text-white hover:border-[#c5a880]/40 transition-colors"
                  aria-label="Close order tracker"
                  id="tracker-close-btn"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Tracker Main Content Body */}
            <div className="flex-1 overflow-y-auto p-5 space-y-6">
              {trackedOrders.length === 0 ? (
                /* Empty state */
                <div className="h-full flex flex-col items-center justify-center text-center px-4 py-12 space-y-5">
                  <div className="w-16 h-16 rounded-full border border-dashed border-[#c5a880]/30 flex items-center justify-center bg-[#121212]">
                    <Clock className="w-7 h-7 text-[#c5a880]/40" />
                  </div>
                  <div>
                    <h4 className="text-white font-serif text-lg font-bold">No active orders found</h4>
                    <p className="text-xs text-gray-500 mt-2 max-w-xs mx-auto leading-relaxed">
                      You haven't placed any orders in this session yet, or there are no active orders for Table 0{selectedTable || '?'}.
                    </p>
                  </div>
                  <button
                    onClick={onClose}
                    className="px-5 py-2.5 rounded-full bg-[#111] border border-[#c5a880]/35 text-[#c5a880] text-xs font-semibold tracking-wider hover:bg-[#c5a880] hover:text-black transition-all duration-300 uppercase"
                    id="tracker-browse-menu-btn"
                  >
                    Browse Our Menu
                  </button>
                </div>
              ) : (
                /* Active / Historic Orders List */
                <div className="space-y-6">
                  {trackedOrders.map((order, orderIdx) => {
                    const progress = getStatusProgress(order.status);
                    const eta = getETA(order);

                    return (
                      <div 
                        key={order.id} 
                        className="p-5 rounded-2xl bg-[#121212] border border-[#c5a880]/10 hover:border-[#c5a880]/20 transition-all duration-300 space-y-5 relative overflow-hidden"
                        id={`tracked-order-${order.id}`}
                      >
                        {/* Status ribbon highlight */}
                        {order.status === 'Completed' && (
                          <div className="absolute top-0 right-0 bg-[#859f7d] text-black text-[9px] font-bold px-3 py-1 rounded-bl-xl tracking-wider uppercase">
                            Delivered
                          </div>
                        )}
                        {order.status === 'Cancelled' && (
                          <div className="absolute top-0 right-0 bg-red-950 border border-red-800 text-red-400 text-[9px] font-bold px-3 py-1 rounded-bl-xl tracking-wider uppercase">
                            Cancelled
                          </div>
                        )}
                        {order.status === 'Preparing' && (
                          <div className="absolute top-0 right-0 bg-amber-500/10 text-amber-400 text-[9px] font-bold px-3 py-1 rounded-bl-xl tracking-wider uppercase border-l border-b border-amber-500/20">
                            In Oven
                          </div>
                        )}

                        {/* Order Metadata */}
                        <div className="flex items-start justify-between">
                          <div className="space-y-1">
                            <span className="font-mono text-[10px] text-[#c5a880] tracking-wider uppercase bg-[#181818] border border-[#c5a880]/15 px-2 py-0.5 rounded-md">
                              ID: #{order.id.slice(-6).toUpperCase()}
                            </span>
                            <div className="flex items-center gap-1.5 mt-2 text-xs text-gray-400">
                              <Calendar className="w-3.5 h-3.5 text-gray-500" />
                              <span>{new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                              <span className="text-gray-700">•</span>
                              <Table className="w-3.5 h-3.5 text-gray-500" />
                              <span>Table {order.tableNumber}</span>
                            </div>
                          </div>
                          
                          {/* Live ETA indicator */}
                          {order.status !== 'Cancelled' && (
                            <div className="text-right">
                              <p className="text-[10px] text-gray-500 uppercase tracking-widest font-semibold">ETA</p>
                              <p className="font-mono text-sm font-bold text-[#e5cfb3] flex items-center gap-1 justify-end mt-0.5">
                                {order.status === 'Preparing' && <Flame className="w-3.5 h-3.5 text-amber-500 animate-pulse" />}
                                {order.status === 'Pending' && <Clock className="w-3.5 h-3.5 text-gray-400 animate-pulse" />}
                                {eta}
                              </p>
                            </div>
                          )}
                        </div>

                        {/* Interactive Status Stepper Timeline */}
                        {order.status !== 'Cancelled' ? (
                          <div className="py-4 border-t border-b border-gray-900 my-2">
                            <div className="relative flex items-center justify-between w-full">
                              
                              {/* Background Connector Bar */}
                              <div className="absolute left-0 right-0 top-1/2 -translate-y-1/2 h-0.5 bg-gray-900 z-0" />
                              
                              {/* Active Progress Filler Bar */}
                              <div 
                                className="absolute left-0 top-1/2 -translate-y-1/2 h-0.5 bg-[#c5a880]/80 z-0 transition-all duration-700" 
                                style={{ width: progress === 1 ? '0%' : progress === 2 ? '50%' : '100%' }}
                              />

                              {/* Step 1: Placed / Pending */}
                              <div className="flex flex-col items-center z-10 relative">
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 ${
                                  progress >= 1 
                                    ? 'bg-[#c5a880] text-black ring-4 ring-[#c5a880]/20' 
                                    : 'bg-[#181818] border border-gray-800 text-gray-600'
                                }`}>
                                  <Clock className="w-4 h-4" />
                                </div>
                                <span className={`text-[9px] mt-1.5 font-bold tracking-wider uppercase ${progress >= 1 ? 'text-[#c5a880]' : 'text-gray-600'}`}>
                                  Placed
                                </span>
                              </div>

                              {/* Step 2: Preparing */}
                              <div className="flex flex-col items-center z-10 relative">
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 ${
                                  progress >= 2 
                                    ? 'bg-[#e5a95d] text-black ring-4 ring-[#e5a95d]/20' 
                                    : progress === 1 ? 'bg-[#181818] border border-[#c5a880]/30 text-[#c5a880] animate-pulse' : 'bg-[#181818] border border-gray-800 text-gray-600'
                                }`}>
                                  <ChefHat className="w-4 h-4" />
                                </div>
                                <span className={`text-[9px] mt-1.5 font-bold tracking-wider uppercase ${progress >= 2 ? 'text-[#e5a95d]' : 'text-gray-600'}`}>
                                  Preparing
                                </span>
                              </div>

                              {/* Step 3: Completed */}
                              <div className="flex flex-col items-center z-10 relative">
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 ${
                                  progress >= 3 
                                    ? 'bg-[#859f7d] text-black ring-4 ring-[#859f7d]/20' 
                                    : 'bg-[#181818] border border-gray-800 text-gray-600'
                                }`}>
                                  <CheckCircle2 className="w-4 h-4" />
                                </div>
                                <span className={`text-[9px] mt-1.5 font-bold tracking-wider uppercase ${progress >= 3 ? 'text-[#859f7d]' : 'text-gray-600'}`}>
                                  Served
                                </span>
                              </div>

                            </div>

                            {/* Status Explanatory Box */}
                            <div className="mt-4 p-3 rounded-lg bg-[#181818] border border-gray-900 text-center">
                              <p className="text-[11px] font-medium text-white tracking-wide">
                                {order.status === 'Pending' && "🕒 Handed over to the kitchen. Cooking starts soon!"}
                                {order.status === 'Preparing' && "🔥 Custom Neapolitan baking inside our 450°C clay-brick wood oven!"}
                                {order.status === 'Completed' && "🎉 Hot, bubbly pizza served directly to your table. Buon Appetito!"}
                              </p>
                            </div>
                          </div>
                        ) : (
                          /* Cancelled State Box */
                          <div className="p-3.5 rounded-lg bg-red-950/20 border border-red-900/35 flex items-center gap-3">
                            <XCircle className="w-5 h-5 text-red-400 shrink-0" />
                            <div>
                              <p className="text-xs font-bold text-red-400">Order Cancelled</p>
                              <p className="text-[10px] text-gray-400 leading-tight mt-0.5">
                                This order was marked as cancelled. Please query with the cash counter or kitchen staff.
                              </p>
                            </div>
                          </div>
                        )}

                        {/* Items summary within the card */}
                        <div className="space-y-2">
                          <p className="text-[10px] font-bold tracking-widest text-[#c5a880]/60 uppercase flex items-center gap-1.5">
                            <Receipt className="w-3.5 h-3.5 text-[#c5a880]/60" />
                            Ordered Dishes
                          </p>
                          <div className="space-y-1.5 bg-[#181818]/60 p-3 rounded-xl border border-gray-900">
                            {order.items.map((item, itemIdx) => (
                              <div key={itemIdx} className="flex justify-between items-center text-xs">
                                <div className="flex items-center gap-1.5">
                                  <span className="text-gray-500 font-mono text-[10px]">x{item.quantity}</span>
                                  <span className="text-gray-200 font-medium">{item.name}</span>
                                </div>
                                <span className="font-mono text-gray-400">₹{(item.price * item.quantity).toFixed(2)}</span>
                              </div>
                            ))}
                            <div className="border-t border-gray-800/60 pt-2 mt-2 flex justify-between items-center">
                              <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Total amount</span>
                              <span className="font-mono text-xs font-bold text-[#c5a880]">₹{order.totalPrice.toFixed(2)}</span>
                            </div>
                          </div>
                        </div>

                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Bottom Safe Note */}
            <div className="p-5 border-t border-[#c5a880]/15 bg-[#111] space-y-4">
              <div className="flex gap-2.5 items-start">
                <AlertTriangle className="w-4 h-4 text-[#c5a880] shrink-0 mt-0.5" />
                <p className="text-[10px] text-gray-500 leading-normal">
                  Our wood-fired pizzas are crafted fresh on order. Estimated arrival times may vary depending on oven queue and peak times. For instant support, please reach out to our service captains.
                </p>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
